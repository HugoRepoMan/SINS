document.addEventListener("DOMContentLoaded", () => {
    loadData();
    // Actualizar cada 5 segundos automáticamente
    setInterval(loadData, 5000); 
});

async function loadData() {
    try {
        const response = await fetch('api/get_alerts.php');
        const data = await response.json();
        
        renderTable('live-table', data.live, ['AlertID', 'TipoAtaque', 'IP_Origen', 'Severidad']);
        renderTable('history-table', data.history, ['LogID', 'TipoAtaque', 'IP_Origen', 'Fecha_Archivado']);
    } catch (error) {
        console.error("Error cargando datos:", error);
    }
}

async function triggerAction(actionType) {
    try {
        const response = await fetch('api/actions.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: actionType })
        });
        const result = await response.json();
        alert(result.message || "Acción completada");
        loadData(); // Recargar tablas inmediatamente
    } catch (error) {
        alert("Error ejecutando acción");
    }
}

function renderTable(tableId, data, columns) {
    const tbody = document.querySelector(`#${tableId} tbody`);
    tbody.innerHTML = "";
    
    if(data.length === 0) {
        tbody.innerHTML = "<tr><td colspan='4'>Sin datos...</td></tr>";
        return;
    }

    data.forEach(row => {
        const tr = document.createElement('tr');
        columns.forEach(col => {
            const td = document.createElement('td');
            // Manejo especial para fechas de SQL Server que vienen como objeto
            if(typeof row[col] === 'object' && row[col] !== null && row[col].date){
                td.textContent = row[col].date.split('.')[0]; 
            } else {
                td.textContent = row[col];
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
}